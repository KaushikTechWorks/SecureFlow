import json
import boto3
import random
import os
from datetime import datetime
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handle_health(event, context):
    """Health check endpoint"""
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
        },
        'body': json.dumps({
            'status': 'healthy',
            'service': 'SecureFlow API',
            'timestamp': datetime.now().isoformat(),
            'version': '2.0-serverless'
        })
    }

def handle_predict(event, context):
    """Handle single transaction prediction - simplified version"""
    try:
        # Parse request body
        body = json.loads(event['body'])
        
        # Extract features
        amount = float(body.get('amount', 0))
        hour = int(body.get('hour', 12))
        day_of_week = int(body.get('day_of_week', 1))
        merchant_category = int(body.get('merchant_category', 0))
        transaction_type = int(body.get('transaction_type', 0))
        
        # Simple rule-based anomaly detection for now
        # We'll replace this with ML model later
        is_anomaly = False
        anomaly_score = 0.0
        risk_level = 'Low'
        
        # Simple rules for anomaly detection
        if amount > 1000:  # High amount
            is_anomaly = True
            anomaly_score = -0.8
            risk_level = 'High'
        elif hour < 6 or hour > 22:  # Unusual hours
            is_anomaly = True
            anomaly_score = -0.6
            risk_level = 'Medium'
        elif amount < 1:  # Very small amount
            is_anomaly = True
            anomaly_score = -0.4
            risk_level = 'Medium'
        else:
            # Normal transaction
            anomaly_score = random.uniform(0.1, 0.3)
            risk_level = 'Low'
        
        # Mock explanation
        explanation = {
            'amount': {
                'value': amount,
                'impact': 'High' if amount > 1000 else 'Low'
            },
            'hour': {
                'value': hour,
                'impact': 'High' if hour < 6 or hour > 22 else 'Low'
            },
            'day_of_week': {
                'value': day_of_week,
                'impact': 'Low'
            },
            'merchant_category': {
                'value': merchant_category,
                'impact': 'Low'
            },
            'transaction_type': {
                'value': transaction_type,
                'impact': 'Low'
            }
        }
        
        # Generate transaction ID
        transaction_id = random.randint(1000, 9999)
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            'body': json.dumps({
                'transaction_id': transaction_id,
                'is_anomaly': is_anomaly,
                'anomaly_score': anomaly_score,
                'confidence': abs(anomaly_score),
                'explanation': explanation,
                'risk_level': risk_level,
                'message': 'Prediction completed successfully'
            })
        }
        
    except Exception as e:
        logger.error(f"Error in prediction: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }

def handle_dashboard(event, context):
    """Handle dashboard data request - mock data for now"""
    try:
        # Mock dashboard data
        dashboard_data = {
            'total_transactions': random.randint(100, 1000),
            'anomalies_detected': random.randint(5, 50),
            'avg_anomaly_score': round(random.uniform(-0.8, 0.3), 3),
            'detection_rate': round(random.uniform(5, 15), 2),
            'last_updated': datetime.now().isoformat()
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            'body': json.dumps(dashboard_data)
        }
        
    except Exception as e:
        logger.error(f"Error in dashboard: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }

def handle_transactions(event, context):
    """Handle transactions list request - mock data"""
    try:
        # Mock transaction data
        transactions = []
        for i in range(10):
            transactions.append({
                'id': random.randint(1000, 9999),
                'amount': round(random.uniform(10, 1500), 2),
                'timestamp': datetime.now().isoformat(),
                'is_anomaly': random.choice([True, False]),
                'risk_level': random.choice(['Low', 'Medium', 'High']),
                'merchant_category': random.randint(0, 9)
            })
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            'body': json.dumps({'transactions': transactions})
        }
        
    except Exception as e:
        logger.error(f"Error in transactions: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }

def handle_root(event, context):
    """Root endpoint - API info"""
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'message': 'SecureFlow API is running',
            'version': '2.0-serverless',
            'timestamp': datetime.now().isoformat(),
            'endpoints': [
                'GET /',
                'GET /health',
                'POST /transactions',
                'GET /transactions',
                'GET /transactions/{id}',
                'GET /analytics',
                'GET /search',
                'POST /fraud-check',
                'GET /compliance/report'
            ]
        })
    }

def handle_create_transaction(event, context):
    """Create a new transaction"""
    try:
        body = json.loads(event['body']) if event.get('body') else {}
        
        transaction = {
            'id': f"tx_{random.randint(1000, 9999)}",
            'amount': body.get('amount', 0),
            'description': body.get('description', 'Test transaction'),
            'category': body.get('category', 'general'),
            'merchant': body.get('merchant', 'Unknown'),
            'timestamp': datetime.now().isoformat(),
            'status': 'completed'
        }
        
        return {
            'statusCode': 201,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(transaction)
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': 'Invalid request data', 'message': str(e)})
        }

def handle_get_transaction(event, context):
    """Get a specific transaction by ID"""
    # Extract transaction ID from path
    path = event.get('path', '')
    parts = path.strip('/').split('/')
    transaction_id = parts[-1] if parts else None
    
    if not transaction_id:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': 'Transaction ID required'})
        }
    
    # Mock transaction data
    transaction = {
        'id': transaction_id,
        'amount': 250.00,
        'description': f'Transaction {transaction_id}',
        'timestamp': datetime.now().isoformat(),
        'status': 'completed'
    }
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(transaction)
    }

def handle_analytics(event, context):
    """Get analytics data"""
    analytics = {
        'total_transactions': 157,
        'total_amount': 47832.50,
        'average_amount': 304.65,
        'transactions_today': 23,
        'fraud_detected': 3,
        'categories': {
            'groceries': 45,
            'restaurants': 32,
            'gas': 28,
            'shopping': 52
        }
    }
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(analytics)
    }

def handle_search(event, context):
    """Search transactions"""
    query = event.get('queryStringParameters', {})
    search_query = query.get('q', '') if query else ''
    
    # Mock search results
    results = [
        {
            'id': 'tx_1001',
            'amount': 45.67,
            'description': f'Search result for: {search_query}',
            'timestamp': datetime.now().isoformat()
        }
    ]
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(results)
    }

def handle_fraud_check(event, context):
    """Fraud detection endpoint"""
    try:
        body = json.loads(event['body']) if event.get('body') else {}
        amount = float(body.get('amount', 0))
        
        # Simple fraud detection logic
        risk_score = min(amount / 1000 * 0.3, 1.0)
        is_suspicious = risk_score > 0.7
        
        result = {
            'risk_score': round(risk_score, 3),
            'is_suspicious': is_suspicious,
            'factors': ['high_amount'] if amount > 1000 else ['normal_transaction'],
            'recommendation': 'Block transaction' if is_suspicious else 'Allow transaction'
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(result)
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': 'Invalid request data'})
        }

def handle_compliance_report(event, context):
    """Generate compliance report"""
    report = {
        'report_date': datetime.now().isoformat(),
        'total_transactions': 1247,
        'flagged_transactions': 18,
        'compliance_score': 96.8,
        'regulatory_status': 'compliant',
        'last_audit': '2025-06-15',
        'next_audit': '2025-12-15'
    }
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(report)
    }

def lambda_handler(event, context):
    """Main Lambda handler that routes requests"""
    
    try:
        # Get the HTTP method and path
        http_method = event.get('httpMethod', 'GET')
        path = event.get('path', '/')
        
        # Handle API Gateway proxy path format
        if 'requestContext' in event and 'path' in event['requestContext']:
            full_path = event['requestContext']['path']
            # Remove the stage prefix (e.g., /prod)
            if full_path.startswith('/prod'):
                path = full_path[5:]  # Remove '/prod'
            else:
                path = full_path
        
        logger.info(f"Received {http_method} request for path: {path}")
        
        # Handle CORS preflight requests
        if http_method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
                },
                'body': ''
            }
        
        # Normalize path - handle both /api/xxx and /xxx patterns
        normalized_path = path
        if not normalized_path.startswith('/api/') and normalized_path != '/':
            if normalized_path.startswith('/'):
                normalized_path = f"/api{normalized_path}"
            else:
                normalized_path = f"/api/{normalized_path}"
        
        # Route requests based on normalized path
        if normalized_path in ['/api/health', '/health']:
            return handle_health(event, context)
        elif normalized_path == '/':
            return handle_root(event, context)
        elif normalized_path == '/api/predict' and http_method == 'POST':
            return handle_predict(event, context)
        elif normalized_path == '/api/dashboard' and http_method == 'GET':
            return handle_dashboard(event, context)
        elif normalized_path in ['/api/transactions', '/transactions'] and http_method == 'GET':
            return handle_transactions(event, context)
        elif normalized_path in ['/api/transactions', '/transactions'] and http_method == 'POST':
            return handle_create_transaction(event, context)
        elif normalized_path.startswith('/api/transactions/') and http_method == 'GET':
            return handle_get_transaction(event, context)
        elif normalized_path in ['/api/analytics', '/analytics'] and http_method == 'GET':
            return handle_analytics(event, context)
        elif normalized_path in ['/api/search', '/search'] and http_method == 'GET':
            return handle_search(event, context)
        elif normalized_path in ['/api/fraud-check', '/fraud-check'] and http_method == 'POST':
            return handle_fraud_check(event, context)
        elif normalized_path in ['/api/compliance/report', '/compliance/report'] and http_method == 'GET':
            return handle_compliance_report(event, context)
        else:
            return {
                'statusCode': 404,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': 'Endpoint not found',
                    'path': path,
                    'normalized_path': normalized_path,
                    'method': http_method,
                    'available_endpoints': [
                        'GET /',
                        'GET /health',
                        'GET /api/health',
                        'POST /api/predict',
                        'GET /api/dashboard',
                        'GET /api/transactions',
                        'POST /api/transactions',
                        'GET /api/transactions/{id}',
                        'GET /api/analytics',
                        'GET /api/search',
                        'POST /api/fraud-check',
                        'GET /api/compliance/report'
                    ]
                })
            }
    
    except Exception as e:
        logger.error(f"Error in lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }
